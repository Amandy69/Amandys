package com.pichincha.automationtest.glue.creditoHipotecario;

import com.pichincha.automationtest.questions.QuesGetText;
import com.pichincha.automationtest.ui.creditoHipotecario.PageCalculadora;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actions.Open;

import com.pichincha.automationtest.tasks.creditoHipotecario.llenarFormularioCredito;
import com.pichincha.automationtest.model.creditoHipotecario.modelDataCredito;

import static net.serenitybdd.screenplay.GivenWhenThen.*;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.CoreMatchers.containsString;

public class solicitarCreditoStepdefs {
    @Given("que el {actor} ingresa y emula el credito en la calculadora de BP")
    public void queElClienteIngresaAEmularElCreditoEnLaCalculadoRaDelBP(Actor actor) {
        givenThat(actor).attemptsTo(
                Open.browserOn().the(PageCalculadora.class)
        );
    }

    @When("llena el formulario con los datos {string}, {string}, {string}, {string} y escoje la {string}")
    public void llenaElFormularioConLosDatosProductoCostoviviendaPrestamodineroPlazoYEscojeLaTablaamortizacion(String producto, String costovivienda, String prestamodinero, String plazo, String tablaamortizacion) {
        when(theActorInTheSpotlight()).attemptsTo(
                llenarFormularioCredito.conDatos(new modelDataCredito(producto,costovivienda,prestamodinero,plazo,tablaamortizacion))
        );

    }

    @Then("el sistema debe de presentarle {string}, {string}, {string}")
    public void elSistemaDebeDePresentarleCuotamensualTasainteresGastosavaluo(String cuotamensual, String tasainteres, String gastosavaluo) {
        then(theActorInTheSpotlight()).should(
                seeThat("cuota mensual ", QuesGetText.fromTarget(PageCalculadora.LABEL_CUOTAMENSUAL), containsString(cuotamensual)),
                seeThat("interes ", QuesGetText.fromTarget(PageCalculadora.LABEL_INTERES), containsString(tasainteres)),
                seeThat("gasto avaluo ", QuesGetText.fromTarget(PageCalculadora.LABEL_GASTOAVALUO), containsString(gastosavaluo))
        );
    }

    }