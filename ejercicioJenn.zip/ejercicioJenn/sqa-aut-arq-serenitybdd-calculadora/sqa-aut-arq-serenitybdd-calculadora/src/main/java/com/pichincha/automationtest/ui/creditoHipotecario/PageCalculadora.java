package com.pichincha.automationtest.ui.creditoHipotecario;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;
import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

@DefaultUrl("page:webdriver.base.url.calculadoraBP") //Ingresar la variable de la url seteada en serenity config
public class PageCalculadora extends PageObject {
    public static final Target CHECKBOX_VIVIENDAPUBLICA = Target.the("'check producto'").located(By.id("setVipVisProductCheckboxInput")); //elementos por ID
    public static final Target TXT_COSTOVIVIENDA = Target.the("'texto costo vivienda '").located(By.id("home-price-calculator")); //elementos por ID
    public static final Target TXT_VALORPRESTAMO = Target.the("'texto solicitud dinero'").located(By.id("requested-amount-calculator")); //elementos por ID
    public static final Target TXT_PLAZO = Target.the("'texto plazo'").located(By.id("loan-term-years-calculator")); //elementos por ID
    public static final Target CHECKBOX_AMORTIZACION = Target.the("'txt amortización'").located(By.id("setGermanAmortizationCheckboxInput")); //elementos por ID
    public static final Target BTN_CALCULAR = Target.the("'boton calcular'").located(By.xpath("html//pichincha-button[@id='calculateButton']")); // elementos po xpath
    public static final Target LABEL_CUOTAMENSUAL = Target.the("'label cuota mensual'").located(By.xpath("/html//div[@id='results']/div[@class='results-container']/pichincha-grid[@class='hydrated']/div/pichincha-grid[1]//div[@class='monthly-fee']")); // elementos po xpath
    public static final Target LABEL_INTERES = Target.the("'label interes'").located(By.xpath("//*[@id=\"results\"]/div[2]/pichincha-grid/div/pichincha-grid[2]/div/pichincha-grid/div/pichincha-grid[1]/div/div[2]/div/div/div[5]/div[2]/pichincha-typography")); // elementos po xpath
    public static final Target LABEL_GASTOAVALUO = Target.the("'label gasto avaluo'").located(By.xpath("//*[@id=\"results\"]/div[2]/pichincha-grid/div/pichincha-grid[2]/div/pichincha-grid/div/pichincha-grid[2]/div/div[2]/div/div/pichincha-grid[2]/div/pichincha-grid[3]/div/div/pichincha-typography")); // elementos po xpath
}