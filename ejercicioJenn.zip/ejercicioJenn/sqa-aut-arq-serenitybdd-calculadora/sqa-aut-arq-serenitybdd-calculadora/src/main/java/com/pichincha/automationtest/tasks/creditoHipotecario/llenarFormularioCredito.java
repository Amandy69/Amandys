package com.pichincha.automationtest.tasks.creditoHipotecario;

import com.pichincha.automationtest.model.creditoHipotecario.modelDataCredito;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Performable;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;

import static com.pichincha.automationtest.ui.creditoHipotecario.PageCalculadora.*;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class llenarFormularioCredito implements Task {

    private final modelDataCredito data;

    public llenarFormularioCredito(modelDataCredito data){
        this.data = data;
    }

    public static Performable conDatos(modelDataCredito data){
        return instrumented(llenarFormularioCredito.class,data);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Click.on(CHECKBOX_VIVIENDAPUBLICA),
                Enter.theValue(data.costovivienda()).into(TXT_COSTOVIVIENDA),
                Enter.theValue(data.prestamodinero()).into(TXT_VALORPRESTAMO),
                Enter.theValue(data.plazo()).into(TXT_PLAZO),
                Click.on(CHECKBOX_AMORTIZACION),
                Click.on(BTN_CALCULAR)
        );
    }
}