package com.pichincha.automationtest.model.creditoHipotecario;

public record modelDataCredito(String producto, String costovivienda, String prestamodinero, String plazo, String tablaamortizacion) {
}
