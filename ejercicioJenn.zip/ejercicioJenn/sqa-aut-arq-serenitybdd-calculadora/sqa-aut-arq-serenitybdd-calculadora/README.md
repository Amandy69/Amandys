# README
Utilizar IDE intelliJ IDEA
Verificar la version del SDK 17 y gradle version 19 en la construccion del proyecto
Al ejecutar el ejemplo ir al archivo "java/com/pichincha/automationtest/runners/WebRunnerTest.java" 
y ejecutar el tag "@CreditoHipotecarioBP" de la linea 21, 
si todo sale bien con la ejecucion del test se agradece su atencion 
DIOS, PATRIA Y LIBERTAD

AAA  :)